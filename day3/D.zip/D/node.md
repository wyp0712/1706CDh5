1. 复习目标：

scss
弹性盒布局
rem + 弹性盒
fleible.js使用

2. 今日学习目标： css3动画

过渡动画 触发动画
自执行动画

⭐️控制动画执行过程
animation-play-state: play | pause;

动画库的使用
自己制作动画库

插件：

html
atuo
path
open
canvas
css

beautify scss less html
live server 起服务  go live

3. 1px;

