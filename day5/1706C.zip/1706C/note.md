一、复习： 

 动画：

 animate.css 动画库
 使用方法： 在需要动画的元素上，加两个类
 animated bounceInDown bounceInUp  Left Right;


 本地存储：
   widow.localStroage {  }
   // 深拷贝：
   var a = JSON.parse(JSON.stringify(obj))
   var b = {
     name: 'hello'
   };
   var c = b;
   sort(function() {})

   
   同源页面访问：
     
二、 今日目标：

  本地存储案例：
  
  eg: input历史记录
     历史记录跳转页面：
     猫眼历史记录：

三、json  js对象表示法；  
 用在哪： 用在前后端交互  json是一个前后端交互的数据类型；
1. 不接受undefined function()
2. 接受数据：number boolean string null
3. json末尾不能有标点
4. json中不能出现注释
5. json格式： {name:[]}  [{}]
6. json 除了特殊类型，都是双引号  number boolean